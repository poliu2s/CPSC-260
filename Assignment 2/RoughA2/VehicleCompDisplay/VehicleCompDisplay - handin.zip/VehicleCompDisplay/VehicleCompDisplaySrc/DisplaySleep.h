
#ifndef DISPLAYSLEEP
#define DISPLAYSLEEP 1

void DisplaySleep(int duration);

#endif