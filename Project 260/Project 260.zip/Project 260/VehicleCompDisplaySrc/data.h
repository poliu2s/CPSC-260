


#ifndef DATA_H
#define DATA_H


#include <iostream>
#include <string>
#include <sstream>
#include "MyLinkedList.h"


using namespace std;




class data {
	
	MyLinkedList inputStorage;
	char wordsearch[10][10];

	int sizeX;
	int sizeY;


public:

	data();
	
	void update(string newData);

	void inputCompleted();

	char getDesiredChar(int x, int y);

	void setArraySize(int rows, int cols);


	int* findword(string interestedWord);

	bool isLetterHere(char letter, int a, int b);

	string stringConverter(int num);




	
};
#endif
