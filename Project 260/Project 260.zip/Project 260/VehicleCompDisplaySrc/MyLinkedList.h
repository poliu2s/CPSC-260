
#pragma once


#include <iostream>
#include <string>
#include <sstream>

using namespace std;


struct Node {
	
	string lineData;
	int identify;
	Node* next;
	
};


class MyLinkedList{

	Node* head;
	int counter;


	void insertLast( const string& item );


public:

	MyLinkedList(void);


	~MyLinkedList(void);


	void insert(string input);
	

	string getLine(int lineNum);

	
	
	int getTotalLines();
};
