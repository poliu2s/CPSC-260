#pragma once


#include <iostream>
#include <string>
#include <sstream>
#include "Simple_window.h"
#include "data.h"		
#include "inputFormatter.h"	
#include "MyLinkedList.h"

#ifndef SEARCHWINDOW_H
#define SEARCHWINDOW_H


struct searchWindow:Window
{
	searchWindow(Point xy, int w, int h, const string& title, data* rawMatrix );
	data* wordSearch;

	Text* displayMatrix[10][10];



private:
	Button find_button;
	Button quit_button;
	In_box next_x;


	static void cb_find(Address, Address);
	void find();
	static void cb_quit(Address, Address);
	void quit();


};



#endif