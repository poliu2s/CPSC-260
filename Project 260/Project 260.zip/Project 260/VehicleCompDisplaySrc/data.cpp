


#include "data.h"
#include "MyLinkedList.h"

#include <iostream>
#include <string>
#include <sstream>



using namespace std;



data::data(){
	
	// Temporary allocation, should be set again later on
	sizeX = 10;
	sizeY = 10;

}


void data::update(string newData){
	
	inputStorage.insert(newData);
}


void data::inputCompleted() {

	string temp;


	for (int i = 0; i < sizeY; i++) {

		temp = inputStorage.getLine(i);

		for (int j = 0; j < sizeX; j++) {
			wordsearch[i][j] = temp[j];
		}
	}
}


char data::getDesiredChar(int x, int y) {

	return wordsearch[x][y];
}


int* data::findword(string interestedWord) {


	// For placeholder pointer,
	// the first number denotes the row that the word starts
	// the second number denotes the column that the word starts
	// the third number denotes the direction that the word appears in (0-7 inclusive)
	/*
			UpLeft = 0
			Up = 1
			UpRight = 2
			Left = 3
			Right = 4
			DownLeft = 5
			Down = 6
			DownRight = 7
	*/


	int *placeholder = new int[3];
	int wordSize = interestedWord.size();
	



	for (int i = 0; i < sizeY; i++) {
		for (int j = 0; j < sizeX; j++) {
			
			
			if (wordsearch[i][j] == interestedWord[0] ) {
				
				int direction = -1;

				// Search up
				bool upResults = false;
				bool continueLoop = true;
				int u = 1;
				while (i-u >= 0 && u < wordSize && continueLoop == true) {
					
					if (wordsearch[i-u][j] == interestedWord[u] ) {
						upResults = true;
						direction = 1;
						cout << "UP" << endl;
						
					}else {
						continueLoop = false;
						upResults = false;
					}
					u++;
				}
				


				// Search down
				bool downResults = false;
				continueLoop = true;
				u = 1;
				while (i+u < sizeY && u < wordSize && continueLoop == true) {
					
					if (wordsearch[i+u][j] == interestedWord[u]) {
						downResults = true;
						direction = 6;
						cout << "DOWN" << endl;
					}else {
						continueLoop = false;
						downResults = false;
					}
					u++;
				}


				// Search left
				bool leftResults = false;
				continueLoop = true;
				u = 1;
				while (j-u >= 0 && u < wordSize && continueLoop == true) {
					
					if (wordsearch[i][j-u] == interestedWord[u]) {
						leftResults = true;
						direction = 3;
						cout << "LEFT" << endl;
					}else {
						continueLoop = false;
						leftResults = false;
					}
					u++;
				}

				
				// Search right
				bool rightResults = false;
				continueLoop = true;
				u = 1;
				while (j+u < sizeX && u < wordSize && continueLoop == true) {
					
					if (wordsearch[i][j+u] == interestedWord[u]) {
						rightResults = true;
						direction = 4;

						cout << "RIGHT" << endl;
					} else {
						continueLoop = false;
						rightResults = false;
					}

					u++;
				}

				// Search Diagonal UpLeft
				bool diagULResults = false;
				continueLoop = true;
				u = 1;
				while (i-u >= 0 && j-u >= 0 && u < wordSize && continueLoop == true) {
					
					if (wordsearch[i-u][j-u] == interestedWord[u]) {
						diagULResults = true;
						direction = 0;
						cout << "UP LEFT" << endl;
					}else {
						continueLoop = false;
						diagULResults = false;
					}
					u++;
				}


				// Search Diagonal DownLeft
				bool diagDLResults = false;
				continueLoop = true;
				u = 1;
				while (i+u < sizeY && j-u >= 0  && u < wordSize && continueLoop == true) {
					
					if (wordsearch[i+u][j-u] == interestedWord[u]) {
						diagDLResults = true;
						direction = 5;
						cout << "DOWN LEFT" << endl;
					}else {
						continueLoop = false;
						diagDLResults = false;
					}
					u++;
				}



				// Search Diagonal Up Right
				bool diagURResults = false;
				continueLoop = true;
				u = 1;
				while (i-u >= 0  && j+u < sizeX && u < wordSize && continueLoop == true) {
					
					if (wordsearch[i-u][j+u] == interestedWord[u]) {
						diagURResults = true;
						direction = 2;
						cout << "UP RIGHT" << endl;
					}else {
						continueLoop = false;
						diagURResults = false;
					}
					u++;
				}


				// Search Diagonal Down Right
				bool diagDRResults = false;
				continueLoop = true;
				u = 1;
				while (i+u < sizeY  && j+u < sizeX && u < wordSize && continueLoop == true) {
					
					if (wordsearch[i+u][j+u] == interestedWord[u]) {
						diagDRResults = true;
						direction = 7;
						cout << "DOWN RIGHT" << endl;
					}else {
						continueLoop = false;
						diagDRResults = false;
					}
					u++;
				}





				if (upResults == true || downResults==true || leftResults==true || rightResults==true ||
					diagULResults==true || diagDLResults==true || diagURResults==true || diagDRResults==true) {

					
					*(placeholder+0) = i;
					*(placeholder+1) = j;
					*(placeholder+2) = direction;
					return placeholder;
				}
				
			}
			
			
		}
	}

	// If word wasn't found, send back error pointer int
	int notFound[3];
	notFound[0] = -1;
	notFound[1] = -1;
	notFound[2] = -1;
	int *didNotFind = notFound;

	return didNotFind;

}

bool data::isLetterHere(char letter, int a, int b) {
	
	if (wordsearch[a][b] == letter) {
		return true;
	}
	return false;
}

void data::setArraySize(int rows, int cols) {
	sizeX = rows;
	sizeY = cols;

}



string data::stringConverter(int num){
	stringstream is;
	is << num;
	string temp = is.str();
	return temp;
}
