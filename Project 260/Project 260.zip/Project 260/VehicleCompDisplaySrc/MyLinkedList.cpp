

#include <iostream>
#include <string>
#include <sstream>
#include "MyLinkedList.h"

MyLinkedList::MyLinkedList() {
	
	counter = 0;
	head = NULL;

}

MyLinkedList::~MyLinkedList() {

	// Add stuff

}

void MyLinkedList::insert(string input) {

	insertLast(input);

	counter++;

}


void MyLinkedList::insertLast(const string& item) {

	Node* newNode = new Node;
	newNode->lineData = item;
	newNode->identify = counter;
	newNode->next = NULL;


	// Find last node and make it point to the newNode (from lecture slides)
	if (head == NULL) {
		head = newNode;

	} else {

		Node* cursor = head;
		while( cursor->next != NULL ) 
			cursor = cursor->next;

		cursor->next = newNode;

	}
}



string MyLinkedList::getLine(int lineNum) {

	Node* cursor = head;
	Node* previousNode = NULL;
	while( cursor != NULL && cursor->identify != lineNum ) {
		previousNode = cursor;
		cursor = cursor->next;
	}

	
	return cursor->lineData;

}